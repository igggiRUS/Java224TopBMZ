package hw02;

// import java.util.Scanner;

public class task09 {
	public static void main(String[] args) {
		double q = 34.145;
		double w = 2.5;
		double e = 10.0;
		double r = 5.0;
		System.out.println(q % 1);
		System.out.println(w % 1);
		System.out.println(e % 1);
		System.out.println(r % 1);
	
	}
}

//
// Может я не прав но вещественные это те у которых остался остаток после нуля.