package hw02;

public class task04 {
public static void main(String[] args) {
	// загуглил ((
	System.out.println("Hello" + "\u0020" + "world");

}
}
